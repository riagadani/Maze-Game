import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.awt.Polygon;
public class MazeProgram extends JPanel implements KeyListener,MouseListener, Runnable
{
	JFrame frame;
	Thread thread;
	ArrayList<Wall> walls = new ArrayList<>();
	ArrayList<Location> batteries = new ArrayList<>();
	//declare an array to store the maze - Store Wall(s) in the array
	int x=100,y=100;
	Maze maze = new Maze();
	Explorer explorer = new Explorer();
	Location end = new Location(0,0);
	ArrayList<Polygon> p = new ArrayList<>();
	boolean display = false;
	long starttime = System.currentTimeMillis();
	long start = System.currentTimeMillis();
	long elapsed = 0;
	long pausetime= 0;
	long pauseelapsed = 0;
	boolean movef = false;
	int fov = 6;
	boolean pause = false;
	boolean info = true;
	boolean gameon;
	//int level = 1;

	public MazeProgram()
	{
		setBoard();
		frame=new JFrame();
		frame.add(this);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1400,850);
		frame.setVisible(true);
		frame.addKeyListener(this);
		thread = new Thread(this);
		thread.start();
		
		//this.addMouseListener(this); //in case you need mouse clicking
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.setColor(Color.BLACK);	//this will set the background color
		g.fillRect(0,0,1400,900);  //since the screen size is 1000x800
									//it will fill the whole visible part
									//of the screen with a black rectangle

		//drawBoard here!

		g.setColor(Color.WHITE);	//x & y would be used to located your
									//playable character
									//values would be set below
									//call the x & y values from your Explorer class
		boolean gameon = explorer.running(maze);

		Color lpurple = new Color(235, 182, 255);
		Color dpurple = new Color(103, 84, 125);
		
		if(gameon && !pause && !info){
			int ceiling = 0;
			int floor = 0;
			int walls = 0;
			g.setColor(lpurple);
			if(fov-2 > 0){
				ceiling = 120/(fov-2);	
			}else{
				ceiling = 152;
			}
			if(fov - 1 > 0){
				floor = 84/(fov-1);
			}else{
				floor = 70;
			}
			if(fov>0){
				walls = 250/fov;
			}
			else{
				walls = 250;
			}
			for(int i = 0; i< 6; i++){
				int[] x = {50*i,50*i,1000-50*i,1000-50*i};
				int[] yt = {50*i,50+50*i,50+50*i,50*i};
				int[] yb = {750-50*i,800-50*i,800-50*i,750-50*i};
				g.setColor(lpurple);
				g.fillPolygon(x,yt,4);
				g.setColor(dpurple);
				g.fillPolygon(x,yb,4);
				g.setColor(Color.BLACK);
				g.drawPolygon(x,yt,4);
				g.drawPolygon(x,yb,4);
				g.setColor(lpurple);
				if(floor*i >= 70||fov == 1){
					dpurple = Color.BLACK;
				}else{
					dpurple = new Color(89-floor*i,70-floor*i,111-floor*i);
				}
				if(ceiling*i >= 152 || fov == 1){
					lpurple = Color.BLACK;
				}else{
					lpurple = new Color(205-ceiling*i,152-ceiling*i,235-ceiling*i);
				}
				
			}
			Color w = Color.WHITE;
			for(int i = 0; i < p.size()-6; i++){
				if(walls*(i%6)>=255){
					w = Color.BLACK;
				}else{
					w = new Color(255-walls*(i%6),255-walls*(i%6),255-walls*(i%6));
				}
				if(i%6==0){
					w = new Color(255,255,255);
				}
				g.setColor(w);
				if(p.get(i) != null){
					g.fillPolygon(p.get(i));
					g.setColor(Color.BLACK);
					g.drawPolygon(p.get(i));
				}
				
			}
			w = Color.WHITE;
			int count = 4;
			
			for(int i = p.size()-5; i<p.size()-1;i++){
				count--;
				if(walls*count > 255){
					w = Color.BLACK;
				}else{
					w = new Color(255-walls*count,255-walls*count,255-walls*count);
				}
				g.setColor(w);
				if(p.get(i) != null){
					g.fillPolygon(p.get(i));
					g.setColor(Color.BLACK);
					g.drawPolygon(p.get(i));
				}
			}
			//batteries
			g.setColor(Color.YELLOW);
			int a = explorer.battery3d(maze);
			if(explorer.battery3d(maze) != -1 && a < fov){
				g.fillPolygon(new int[]{400+20*a,600-20*a,600-20*a,400+20*a},
							  new int[]{350+10*a,350+10*a,450-10*a,450-10*a},4);
				g.setColor(Color.BLACK);
				g.setFont(new Font("Times New Roman",Font.PLAIN,50-10*a));
				g.drawString("+", 490,410);
			}
			//crumbs
			g.setColor(Color.GREEN);
			int b = explorer.getCrumbs3d(maze);
			if(b != -1 && b< fov){
				g.fillPolygon(new int[]{400+20*b,600-20*b,600-20*b,400+20*b},
							  new int[]{350+10*b,350+10*b,450-10*b,450-10*b},4);
			}
			//endwalls
			g.setColor(Color.BLACK);
			int c = explorer.getEndWall(maze);
			if(c != -1 && c < fov){
				g.fillPolygon(new int[]{50*c,50*c,1000-50*c,1000-50*c},
							  new int[]{50*c,800-50*c,800-50*c,50*c},4);
			}
			
		}
		
		/*g.setColor(Color.WHITE);
		if(gameon){
			for(int i = 0; i < p.size(); i++){
				g.fillPolygon(p.get(i));
				g.setColor(Color.BLACK);
				g.drawPolygon(p.get(i));
				g.setColor(Color.WHITE);
			}
		}*/
		if(gameon && display && !pause && !info){
			ArrayList<Wall> w = maze.getWalls();
			g.setColor(Color.BLACK);
			g.fillRect(0,0,1400,800);
			g.setColor(Color.WHITE);
			for(int i = 0; i<w.size(); i++){
				g.fillRect(w.get(i).getX()*20,w.get(i).getY()*20,20,20);
			}
			g.setColor(Color.RED);
			int direction = explorer.getDirection();
			switch(direction){
				case 1: g.fillPolygon(new int[]{explorer.getX()*20, explorer.getX()*20+10, explorer.getX()*20+20},
									  new int[]{explorer.getY()*20+20, explorer.getY()*20, explorer.getY()*20+20}, 3);
						break;
				case 2: g.fillPolygon(new int[]{explorer.getX()*20, explorer.getX()*20+20, explorer.getX()*20},
									  new int[]{explorer.getY()*20, explorer.getY()*20+10, explorer.getY()*20+20}, 3);
						break;
				case 3: g.fillPolygon(new int[]{explorer.getX()*20, explorer.getX()*20+10, explorer.getX()*20+20},
									  new int[]{explorer.getY()*20, explorer.getY()*20+20, explorer.getY()*20}, 3);
						break;
				case 4: g.fillPolygon(new int[]{explorer.getX()*20, explorer.getX()*20+20, explorer.getX()*20+20},
									  new int[]{explorer.getY()*20+10, explorer.getY()*20, explorer.getY()*20+20}, 3);
						break;
			}
			//batteries
			g.setColor(Color.YELLOW);
			for(int i = 0; i < maze.getBatteries().size(); i++){
				g.fillPolygon(new int[]{maze.getBatteries().get(i).getX()*20, maze.getBatteries().get(i).getX()*20+20, maze.getBatteries().get(i).getX()*20+20, maze.getBatteries().get(i).getX()*20},
							  new int[]{maze.getBatteries().get(i).getY()*20+5, maze.getBatteries().get(i).getY()*20+5, maze.getBatteries().get(i).getY()*20+15, maze.getBatteries().get(i).getY()*20+15},4);
				g.setColor(Color.BLACK);
				g.setFont(new Font("Times New Roman",Font.PLAIN,15));
				g.drawString("+", maze.getBatteries().get(i).getX()*20+7,maze.getBatteries().get(i).getY()*20+15);
				g.setColor(Color.YELLOW);
			}

			//breadcrumbs
			g.setColor(Color.GREEN);
			for(int i = 0; i < explorer.getCrumbs().size(); i++){
				g.fillPolygon(new int[]{explorer.getCrumbs().get(i).getX()*20, explorer.getCrumbs().get(i).getX()*20+20, explorer.getCrumbs().get(i).getX()*20+20, explorer.getCrumbs().get(i).getX()*20,explorer.getCrumbs().get(i).getX()*20},
							  new int[]{explorer.getCrumbs().get(i).getY()*20, explorer.getCrumbs().get(i).getY()*20, explorer.getCrumbs().get(i).getY()*20+20, explorer.getCrumbs().get(i).getY()*20+20}, 4);
			}
		}
		if(pause){
			g.setColor(Color.BLACK);
			g.fillRect(0,0,1400,900);
			g.setColor(Color.WHITE);
			g.setFont(new Font("Times New Roman",Font.PLAIN,30));
			g.drawString("Paused", 500, 300);

		}
		if(info){
			g.setColor(Color.BLACK);
			g.fillRect(0,0,1400,900);
			g.setColor(Color.WHITE);
			g.setFont(new Font("Times New Roman",Font.PLAIN,30));
			g.drawString("Instructions", 0, 35);
			g.drawString("To move press the up arrow key.", 0, 70);
			g.drawString("To turn press the left or right arrow keys.", 0, 105);
			g.drawString("Press p to pause the game.", 0, 140);
			g.drawString("You have 5 breakcrumbs. Use d to drop them. They appear as green rectangles.", 0, 175);
			g.drawString("Your flashlight has a 30 second timer. Get Batteries (yellow rectangles) to replenish the timer.", 0, 210);
			g.drawString("Press the space bar to switch between 3d and 2d mazes.", 0, 245);
			g.drawString("Press i to start the maze and pull up the instructions again if needed.", 0, 280);
		}
		if(!gameon /*&& level == 2*/){
			g.setFont(new Font("Times New Roman",Font.PLAIN,30));
			g.drawString("You have reached the end!", 500, 300);	
			
		}					//explorer.getX() and explorer.getY()
		
		//other commands that might come in handy
		//g.setFont("Times New Roman",Font.PLAIN,18);
				//you can also use Font.BOLD, Font.ITALIC, Font.BOLD|Font.Italic
		//g.drawOval(x,y,10,10);
		//g.fillRect(x,y,100,100);
		//g.fillOval(x,y,10,10);
		
		//compass
		if(gameon && !pause && !info){
			g.setColor(Color.CYAN);
			g.fillOval(925,725,75,75);
			g.setColor(Color.BLACK);
			g.setFont(new Font("Times New Roman", Font.PLAIN, 25));
			g.drawString("N", 957, 745);
			g.drawString("S", 957, 795);
			g.drawString("E", 985, 770);
			g.drawString("W", 927, 770);
			g.setColor(Color.BLUE);
			switch(explorer.getDirection()){
				case 1: g.drawString("N", 957, 745);
						break;
				case 2: g.drawString("E", 985, 770);
						break;
				case 3: g.drawString("S", 957, 795);
							break;
					case 4: g.drawString("W", 927, 770);
							break;
			}
			//crumbs left
			g.setColor(Color.BLACK);
			g.setFont(new Font("Times New Roman", Font.PLAIN, 30));
			g.drawString(explorer.crumbsLeft() + "/5 crumbs left.", 740, 780);
		}
		
	}
	public void run(){
		
		while(true){
			boolean gameon = explorer.running(maze);
			/*if(level < 3 && !gameon){
				level++;
				maze = new Maze();
				explorer = new Explorer();
				p = new ArrayList<>();
				walls = new ArrayList<>();
				batteries = new ArrayList<>();
				setBoard();
			}*/
			if(gameon && !pause && !info){
				if(movef){
					explorer.move(maze);
				}
			}
			if(explorer.battery(maze)){
				fov = 6;
			}
			if(pause){
				pauseelapsed = System.currentTimeMillis() - pausetime;
			}
			elapsed = System.currentTimeMillis() - start - pauseelapsed;
			if(fov > 1 && elapsed >= 30000){
				start = System.currentTimeMillis();
				pauseelapsed = 0;
				fov--;
				elapsed = 0;
			}
		
		
			try{
				thread.sleep(70);
			}
			catch(InterruptedException e){
			}
			setWalls();
			repaint();
		}
	}
	public void setBoard()
	{
		//choose your maze design

		//pre-fill maze array here

		File name = new File("maze1.txt");
		int count = 0;
		
		try
		{
			BufferedReader input = new BufferedReader(new FileReader(name));
			String text;
			while( (text=input.readLine())!= null)
			{
				char[] w = text.toCharArray();
				for(int i = 0; i < w.length; i++){
					if(w[i] == '#'){
						walls.add(new Wall(new Location(i, count)));
					}
					if(w[i] == 's'){
						explorer.setStart(new Location(i,count));
					}
					if(w[i] == 'e'){
						end.setLocation(i, count);
					}
					if(w[i] == 'b'){
						batteries.add(new Location(i, count));
					}
				}
				count++;
				//your code goes in here to chop up the maze design
				//fill maze array with actual maze stored in text file
			}
		}
		catch (IOException io)
		{
			System.err.println("File error");
		}

		maze.addWalls(walls);
		maze.setEnd(end);
		maze.addBatteries(batteries);
		setWalls();
	}

	public void setWalls()
	{
		//when you're ready for the 3D part
		//int[] c1X={150,550,450,250};
		//int[] c1Y={50,50,100,100};
		//Wall ceiling1=new Wall(c1X,c1Y,4);  //needs to be set as a global!
						//parameters - x coordinates, y coordinates, # of points
		
		//left walls
		p = new ArrayList<>();
		for(int i = 0; i < 6; i++){
			int[] xl = {50*i,50*i,50+50*i,50+50*i};
			int[] y = {50+50*i,750-50*i,750-50*i,50+50*i};
			p.add(new Polygon(xl,y,4));
		}
		for(int i = 0; i < 6; i++){
			int[] xr = {1000-50*i,1000-50*i,950-50*i,950-50*i};
			int[] y = {50+50*i,750-50*i,750-50*i,50+50*i};
			p.add(new Polygon(xr,y,4));
		}

		int[] l = explorer.getLeft(maze);
		
		for(int i = 0; i < 6; i++){
			int[] x = {50*i,50*i,50+50*i,50+50*i};
			int[] y = {50*i,800-50*i,750-50*i,50+50*i};
			if(l[i] == 1){
				p.add(new Polygon(x,y,4));
			}
			else{
				p.add(null);
			}
		}
		//right walls
		int[] r = explorer.getRight(maze);
		
		for(int i = 0; i < 6; i++){
			int[] x = {1000-50*i,1000-50*i,950-50*i,950-50*i};
			int[] y = {0+50*i,800-50*i,750-50*i,50+50*i};
			if(r[i] == 1){
				p.add(new Polygon(x,y,4));
			}else{
				p.add(null);
			}
		}
		//center
		int[] c = explorer.getCenter(maze);

		for(int i = 5; i >= 0; i--){
			int[] x = {50*i,50*i,1000-50*i,1000-50*i};
			int[] y = {50*i,800-50*i,800-50*i,50*i};
			if(c[i] == 1){
				p.add(new Polygon(x,y,4));
			}else{
				p.add(null);
			}
		}
		explorer.setEndWall(maze);
	}



	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode()){
			case 37: if(!pause && !info){
						explorer.turn(0);
					}
					break;
			case 38: movef = true;
					break;
			case 39: if(!pause && !info){
						explorer.turn(1);
					}
					break;
			/*case 40: if(!pause && !info){
						explorer.turn(0);
						 explorer.turn(0);
					}
					break;*/
			case 32: if(display){
						display = false;
					}else{
						display = true;
					}
					break;
			case 80: if (pause){
						pause = false;
					}else{
						pause = true;
						pausetime = System.currentTimeMillis();
					}
					break;
			case 68: if(!pause && !info){
						explorer.dropCrumb();
					}
					break;
			case 73: if(info){
						info = false;
					}else{
						info = true;
						pausetime = System.currentTimeMillis();
					}
		}

		


	}
	public void keyReleased(KeyEvent e)
	{
		if(e.getKeyCode()==38){
			movef = false;
		}
	}
	public void keyTyped(KeyEvent e)
	{
	}
	public void mouseClicked(MouseEvent e)
	{
	}
	public void mousePressed(MouseEvent e)
	{
	}
	public void mouseReleased(MouseEvent e)
	{
	}
	public void mouseEntered(MouseEvent e)
	{
	}
	public void mouseExited(MouseEvent e)
	{
	}
	public static void main(String args[])
	{
		MazeProgram app=new MazeProgram();
	}
}