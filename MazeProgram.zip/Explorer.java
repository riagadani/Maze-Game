import java.util.ArrayList;
public  class Explorer{
  private Location l;
  private int direction;
  private ArrayList<Location> crumbs;
  private ArrayList<Location> endwall;

  public Explorer(Location l){
    this.l = l;
    direction = 3;
    crumbs = new ArrayList<>();
    endwall = new ArrayList<>();
    // 1 N, 2 E, 3 S, 4 W
  }
  public Explorer(){
    direction = 3;
    crumbs = new ArrayList<>();
    endwall = new ArrayList<>();
  }
  public void setEndWall(Maze maze){
    endwall.add(new Location(maze.getEnd().getX()+1, maze.getEnd().getY()));
  }
  public int getEndWall(Maze maze){
    return fov(endwall, maze);
  }
  public void setStart(Location l){
    this.l = l;
  }
  public void dropCrumb(){
    int x = l.getX();
    int y = l.getY();
    Location temp = new Location(x,y);
    if(crumbs.size() < 5){
      crumbs.add(temp);
    }
  }
  public ArrayList<Location> getCrumbs(){
    return crumbs;
  }
  public int getCrumbs3d(Maze maze){
    return fov(crumbs, maze);
  }
  public int crumbsLeft(){
    return 5 - crumbs.size();
  }
  public void move(Maze maze){
    int tempx = l.getX();
    int tempy = l.getY();
    switch(direction){
      case 1: l.addY(-1);
              break;
      case 2: l.addX(1);
              break;
      case 3: l.addY(1);
              break;
      case 4: l.addX(-1);
    }
    if(maze.isWall(l) || l.getX() < 0 || l.getY() < 0){
      l.setLocation(tempx, tempy);
    }
    if(l.equals(maze.getEnd())){
      l = maze.getEnd();
    }
    
  }
  public int battery3d(Maze maze){
    return fov(maze.getBatteries(), maze);
    /*int x = l.getX();
    int y = l.getY();
    for(int j = 0; j<maze.getBatteries().size(); j++){
      for(int i = 0; i< 6; i++){
        switch(direction){
        case 1: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(x == maze.getWalls().get(z).getX() && y - i == maze.getWalls().get(z).getY()){
                    return -1;
                  }
                }
                if (x == maze.getBatteries().get(j).getX() && y-i == maze.getBatteries().get(j).getY()){
                  return i;
                }
                break;
        case 2: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(y == maze.getWalls().get(z).getY() && x + i == maze.getWalls().get(z).getX()){
                    return -1;
                  }
                }
                if (y == maze.getBatteries().get(j).getY() && x + i == maze.getBatteries().get(j).getX()){
                  return i;
                }
                break;
        case 3: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(x == maze.getWalls().get(z).getX() && y + i == maze.getWalls().get(z).getY()){
                    return -1;
                  }
                }
                if (x == maze.getBatteries().get(j).getX() && y + i == maze.getBatteries().get(j).getY()){
                  return i;
                }
                break;
        case 4: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(y == maze.getWalls().get(z).getY() && x - i == maze.getWalls().get(z).getX()){
                    return -1;
                  }
                }
                if(y == maze.getBatteries().get(j).getY() && x - i == maze.getBatteries().get(j).getX()){
                  return i;
                }
                break;
      }
      }
      
    }
    return -1;
    */
  }
  public boolean battery(Maze maze){
    for(int i = 0; i < maze.getBatteries().size(); i++){
      if(maze.getBatteries().get(i).equals(l)){
        maze.useBattery(i);
        return true;
      }
    }
    return false;
  }
  public void turn(int a){
    // 0 is left, 1 is right
    if (a == 1){
      if (direction == 4){
        direction = 1;
      }else{
        direction++;
      }
    }
    if (a == 0){
      if (direction == 1){
        direction = 4;
      }else{
        direction--;
      }
    }
  }
  public Location getLocation(){
    return l;
  }
  public int getX(){
    return l.getX();
  }
  public int getY(){
    return l.getY();
  }
  public int getDirection(){
    return direction;
  }
  public boolean running(Maze maze){
    if(l.equals(maze.getEnd())){
      return false;
    }
    return true;
  }
  public int[] getLeft(Maze maze){
    //0 is false, 1 is true
    int[] left = {0,0,0,0,0,0};
     switch (direction){
      case 1: for(int i = 0; i< 6; i++){
                if (maze.isWall(new Location(l.getX()-1, l.getY()-i))){
                   left[i] = 1;
                }
              }
              
            break;
      case 2: for(int i = 0; i< 6; i++){
                if (maze.isWall(new Location(l.getX()+i, l.getY()-1))){
                   left[i] = 1;
                }
              }
              break;
      case 3: for(int i = 0; i< 6; i++){
                if (maze.isWall(new Location(l.getX()+1, l.getY()+i))){
                   left[i] = 1;
                }
              }
              break;
      case 4: for(int i = 0; i< 6; i++){
                if (maze.isWall(new Location(l.getX()-i, l.getY()+1))){
                   left[i] = 1;
                }
              }
              break;
      }
    return left;
  }
  public int[] getRight(Maze maze){
    int[] right = {0,0,0,0,0,0};
    for(int i = 0; i < 6; i++){
      switch (direction){
        case 1: if (maze.isWall(new Location(l.getX()+1, l.getY()-i))){
                  right[i] = 1;
                }
              break;
        case 2: if(maze.isWall(new Location(l.getX()+i, l.getY()+1))){
                  right[i] = 1;
                }
                break;
        case 3: if (maze.isWall(new Location(l.getX()-1, l.getY()+i))){
                 right[i] = 1;
                }
                break;
        case 4: if(maze.isWall(new Location(l.getX()-i, l.getY()-1))){
                  right[i] = 1;
                }
                break;
        }
    }
    return right;
  }
  public int[] getCenter(Maze maze){
    int[] center = {0,0,0,0,0,0};
    for(int i = 0; i < 6; i++){
      switch(direction){
       case 1: if (maze.isWall(new Location(l.getX(), l.getY()-i))){
                  center[i] = 1;
                }
              break;
        case 2: if(maze.isWall(new Location(l.getX()+i, l.getY()))){
                  center[i] = 1;
                }
                break;
        case 3: if (maze.isWall(new Location(l.getX(), l.getY()+i))){
                 center[i] = 1;
                }
                break;
        case 4: if(maze.isWall(new Location(l.getX()-i, l.getY()))){
                  center[i] = 1;
                }
                break; 
      }
    }
    return center;
  }
  public int fov(ArrayList<Location> array, Maze maze){
    int x = l.getX();
    int y = l.getY();
    for(int j = 0; j<array.size(); j++){
      for(int i = 0; i< 6; i++){
        switch(direction){
        case 1: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(x == maze.getWalls().get(z).getX() && y - i == maze.getWalls().get(z).getY()){
                    return -1;
                  }
                }
                if (x == array.get(j).getX() && y-i == array.get(j).getY()){
                  return i;
                }
                break;
        case 2: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(y == maze.getWalls().get(z).getY() && x + i == maze.getWalls().get(z).getX()){
                    return -1;
                  }
                }
                if (y == array.get(j).getY() && x + i == array.get(j).getX()){
                  return i;
                }
                break;
        case 3: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(x == maze.getWalls().get(z).getX() && y + i == maze.getWalls().get(z).getY()){
                    return -1;
                  }
                }
                if (x == array.get(j).getX() && y + i == array.get(j).getY()){
                  return i;
                }
                break;
        case 4: for(int z = 0; z<maze.getWalls().size(); z++){
                  if(y == maze.getWalls().get(z).getY() && x - i == maze.getWalls().get(z).getX()){
                    return -1;
                  }
                }
                if(y == array.get(j).getY() && x - i == array.get(j).getX()){
                  return i;
                }
                break;
      }
      }
      
    }
    return -1;
  }
}
