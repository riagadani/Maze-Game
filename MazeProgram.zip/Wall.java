public class Wall{
   private  Location w;
   public Wall(Location a){
       w = a;
   }
   public Location getLocation(){
       return w;
   }
   public int getX(){
       return w.getX();
   }
   public int getY(){
       return w.getY();
   }
}