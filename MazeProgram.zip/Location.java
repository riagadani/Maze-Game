public class Location{
  private int x;
  private int y;
  public Location(int a, int b){
    x = a;
    y = b;
  }
  public void addX(int a){
    x += a;
  }
  public void addY(int b){
    y += b;
  }
  public int getX(){
    return x;
  }
  public int getY(){
    return y;
  }
  public void setLocation(int a, int b){
    x = a;
    y = b;
  }
  public boolean equals(Location a){
    if (a.getX() == x && a.getY() == y){
      return true;
    }
    return false;
  }
  public String toString(){
    return x + " " + y;
  }
}
