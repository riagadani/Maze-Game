import java.util.ArrayList;
public class Maze{
    private ArrayList<Wall> walls;
    private Location end;
    private ArrayList<Location> batteries;
    public Maze(){
        walls = new ArrayList<>();
        batteries = new ArrayList<>();
    }
    public void addWalls(ArrayList<Wall> walls){
        this.walls = walls;
        batteries = new ArrayList<>();
    }
    public void addBatteries(ArrayList<Location> b){
        batteries = b;
    }
    public ArrayList<Location> getBatteries(){
        return batteries;
    }
    public void useBattery(int index){
        batteries.remove(index);
    }
    public boolean isWall(Location x){
        for (int i = 0; i<walls.size(); i++){
            if (walls.get(i).getLocation().equals(x)){
                return true;
            }
        }
        return false;
    }
    public ArrayList<Wall> getWalls(){
        return walls;
    }
    public void setEnd(Location e){
        end = e;
    }
    public Location getEnd(){
        return end;
    }
}